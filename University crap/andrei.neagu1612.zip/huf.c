#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//Structura nodului pentru coada de prioritate
typedef struct node_q{ 
    int priority; 
  	struct node_q* next;
  	struct node_q* child0;
  	struct node_q* child1;
  	int data; 
} Node_q; 

//Facem un nod nou pentru coada de prioritate
Node_q* newNode_q(int dat, int prio){ 
    Node_q* nodeaux = (Node_q*)malloc(sizeof(Node_q)); 
    nodeaux->data = dat;
    nodeaux->next = NULL;
    nodeaux->child0 = NULL;
    nodeaux->child1 = NULL;
    nodeaux->priority = prio;
    return nodeaux; 
}


//Verifica daca e goala coada de prioritate
int isEmpty_q(Node_q** head_q){
	if((*head_q) == NULL)
    	return 1;
    else
    	return 0;
}

//Scoatem primul nod din coada de prioritate
void pop_q(Node_q** head_q){
    Node_q* aux = *head_q;
    (*head_q) = (*head_q)->next;
}

//Afisam primul nod din coada de prioritate
Node_q* showhead_q(Node_q** head_q){ 
    return (*head_q); 
}

//Adaugam un nod nou in coada de prioritate
void add_to_q(Node_q** head, Node_q** nod){
    Node_q* start = (*head); 
    if (((*head)->priority) > (*nod)->priority){
    	//daca nodul nou are o prioritate mai mare decat capul listei
        (*nod)->next = *head; 
        (*head) = (*nod); 
    }
    else{
        //Cautam in lista locul dorit pentru prioritatea indicata
        while (start->next != NULL){
            if(start->next->priority < (*nod)->priority)
            	start = start->next;
        	else
        		break;
        }
  		//Inseram nodul pe pozita gasita
 		(*nod)->next = start->next; 
        start->next = (*nod); 
    }
}

void showtree(Node_q** start,char **a,int i,FILE **fp){
	if((*start)->child0 !=NULL){
		(*a)[i]='0';
		i++;
		showtree(&((*start)->child0),&(*a),i,&(*fp));
		i--;
		(*a)[i]='\0';
	}
	if((*start)->child1 !=NULL){
		(*a)[i]='1';
		i++;
		showtree(&((*start)->child1),&(*a),i,&(*fp));
		i--;
		(*a)[i]='\0';
	}
	if((*start)->child1 ==NULL && (*start)->child0 ==NULL){
		(*a)[i]='\0';
		fprintf((*fp),"%s -> %c are %d aparitii \n",*a,(char)(*start)->data,(*start)->priority);
	}

}

int main(int argc, char *argv[])
{
	//Folosim aceste siruri pentru fisierele de input si output 
    char* filename =(char*) malloc(sizeof(char)*20);
    char* filename1 =(char*) malloc(sizeof(char)*20);
    strcat(filename,"test");
    strcat(filename,argv[1]);
    strcat(filename1,filename);
    strcat(filename1,"_huf.out");
    strcat(filename,".in");    
   	FILE *fp;
   	FILE *fp1;
   	fp = fopen(filename, "r");
   	fp1 = fopen(filename1, "w");
   	char str[10000];
   	char buff[1000];
   	fgets(str, 1000, fp);
	str[strlen(str)-1]='\0';
	while(!feof(fp)){
	   	fgets(buff, 1000, fp);
	   	if(buff[strlen(buff)-1]=='\n')
	   		buff[strlen(buff)-1]='\0';
	   	strcat(str,buff);
	}
    //Calculam frecventa fiecarui caracter
    int i,frequently[256];
	for(i = 0; i<256; i++)
    	frequently[i] = 0;
	for(i = 0; i<strlen(str); i++)
    	frequently[(int)(str[i])]++;

    //Facem noduri noi pe care sa le punem in coada de prioritate,
    //,numarul de aparitii va fi prioritatea

    int j;
    Node_q* firstnode;
    for(j = 0; j<256; j++){
    	if(frequently[j]){
    		firstnode =(Node_q*)malloc(sizeof(Node_q));
    		firstnode->priority=frequently[j];
    		firstnode->data=j;
    		break;
    	}
	}
	
    for(i = j+1; i<256; i++){
    	if(frequently[i]){
    		Node_q* addnode = newNode_q(i, (frequently[i]));
       		add_to_q(&firstnode,&addnode);
    	}
	}
	Node_q *child0;
	Node_q *child1;
	while(firstnode!=NULL ){
		if(firstnode->next==NULL)
			break;
	    child0 = showhead_q(&firstnode);
		pop_q((&firstnode));
    	child1 = showhead_q(&firstnode);
    	Node_q *nodtriere = newNode_q(0,(child1->priority + child0->priority));
    	nodtriere->child0=child0;
		nodtriere->child1=child1;
		add_to_q(&firstnode,&nodtriere);
		pop_q((&firstnode));
    }
	char *a = (char*)malloc(sizeof(char)*200);
	if(firstnode!=NULL)
    	showtree(&firstnode,&a,0,&fp1);
    fclose(fp);
    fclose(fp1);

    return 0; 
 
}