#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{
    char* key;
    int val;
    struct node *next;
};
struct table{
	int actualsize;
    int size;
    struct node **list;
};
struct table *createTable(int size){
    struct table *t = (struct table*)malloc(sizeof(struct table));
    t->size = size;
    t->list = (struct node**)malloc(sizeof(struct node*)*size);
    int i;
    t->actualsize=0;
    for(i=0;i<size;i++)
        t->list[i] = NULL;
    return t;
}
void insert(struct table *t,char* key,int val){
    int pos = t->actualsize;
    struct node *list = t->list[pos];
    struct node *newNode = (struct node*)malloc(sizeof(struct node));
    struct node *temp = list;
    while(temp){
        if(strcmp(temp->key,key)==0){
            temp->val = val;
            return;
        }
        temp = temp->next;
    }
    newNode->key = key;
    newNode->val = val;
    newNode->next = list;
    t->list[pos] = newNode;
}
int lookup(struct table *t,char* key){
    int pos = t->actualsize;
    struct node *list = t->list[pos];
    struct node *temp = list;
    while(temp){
        if(strcmp(temp->key,key)==0){
            return temp->val;
        }
        temp = temp->next;
    }
    return -1;
}
int main(int argc, char *argv[]){
	char* test="test";
    char* filename =(char*) malloc(sizeof(char)*10);
    char* filename1 =(char*) malloc(sizeof(char)*10);
    strcat(filename,test);
    strcat(filename,argv[1]);
    strcat(filename1,filename);
    strcat(filename1,"_lzw.out");
    strcat(filename,".in");
    char buff[1000];
    char s1[10000];
   	FILE *fp;
   	FILE *fp1;
   	fp = fopen(filename, "r");
   	fp1 = fopen(filename1, "w");
	fgets(s1, 1000, fp);
	s1[strlen(s1)-1]='\0';
	while(!feof(fp)){
	   	fgets(buff, 1000, fp);
	   	if(buff[strlen(buff)-1]=='\n')
	   		buff[strlen(buff)-1]='\0';
	   	strcat(s1,buff);
	}
    struct table *tab = createTable(10000);
    fprintf(fp1,"Encoding\n");  
    for (int i = 0; i <= 255; i++) { 
        char ch[2];
        ch[0]=i;
        ch[1]='\0'; 
        insert(tab,ch,i); 
    }
    char p[400]; 
    char c[200];

    p[0]=s1[0];
    p[1]='\0';
    int code = 256;
    int count = 0;
    count++;        
    struct table *tabout = createTable(10000);
    insert(tabout,p,count);
    fprintf(fp1,"String\tOutput_Code\n");
    strcpy(p,"\0");
   	strcpy(c,"\0");
   	char *aux=(char*)malloc(sizeof(char)*400);
    for (int i = 0; i < strlen(s1); i++) {
		strcpy(aux,"\0");
        if (i != strlen(s1) - 1) {
    		char aux2[20];
    		aux2[0]=s1[i+1];
    		aux2[1]='\0';
    		strcpy(c,aux2);
    	}
       	strcpy(aux,p);
        strcat(aux,c);
        if (lookup(tabout,aux) != -1) {
            strcat(p,c);
        }
        else {  
        	char x[20];
        	strcat(x,aux);
        	insert(tabout,x,count);
            fprintf(fp1,"%s \t %d \n",aux,lookup(tabout,x));
        	count++;
        	strcpy(p,c);
        }  
	    strcpy(c,"\0");
	} 
    fprintf(fp1,"%s \t %d\n",p,lookup(tabout,p));

    fclose(fp);
    fclose(fp1);
 
    return 0;
}
