#include <stdlib.h>
#include <stdio.h>
typedef struct S{
	int currentValue;
	int minValue;
	int maxValue;
	int worstcase;
}stock;

int main(){
	FILE *fp;
	fp = fopen("stocks.in", "r");
	FILE *fp1;
	fp1 = fopen("stocks.out", "w+");
	int N;
	char buff;
	fscanf(fp, "%d", &N);
	fscanf(fp,"%c", &buff);
	int *valley = (int*) malloc(sizeof(int)*(N+2));
	for (int i = 0; i < N; ++i){
		fscanf(fp, "%d", &valley[i]);
		fscanf(fp,"%c", &buff);	
	}
	fclose(fp);
	
	int best_sol=0;
	int min=valley[1];
	int minpoz=1;
	int *valleycpy = (int*) malloc(sizeof(int)*(N+2));
	
	for (int i = 0; i < N; ++i){
		valleycpy[i]=valley[i];
	}

	if (valley[0] < valley[1]){
		best_sol+=valley[0]-min;
		min=valley[0];
		minpoz=0;
		valleycpy[1]=valleycpy[0];
	}

	for (int j = 2; j < N-1; ++j){
	
		for (int i = 2; i < N; ++i){
			if(min>valley[i]){
				min=valley[i];
				minpoz=i;
			}
		}

		if(minpoz<j){
			best_sol+=valleycpy[j]-min;
			valleycpy[j]-=valleycpy[j]-min;
		}
		
	}
	free(valleycpy);
	free(valley);
	fprintf(fp1, "%d\n",best_sol);
	fclose(fp1);
	return 0;
}