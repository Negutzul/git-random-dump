#include <stdlib.h>
#include <stdio.h>
typedef struct S{
	int currentValue;
	int minValue;
	int maxValue;
	int worstcase;
}stock;

int max(int x, int y)
{
    if(x>y)
    	return x;
    return y;
}
 

int main(){
	FILE *fp;
	fp = fopen("stocks.in", "r");
	FILE *fp1;
	fp1 = fopen("stocks.out", "w+");
	int N,B,L;
	char buff;
	fscanf(fp, "%d", &N);
	fscanf(fp,"%c", &buff);
	fscanf(fp, "%d", &B);
	fscanf(fp,"%c", &buff);	
	fscanf(fp, "%d", &L);
	fscanf(fp,"%c", &buff);	
	
	stock *list = (stock*)malloc(sizeof(stock)*(N+2));

	for (int i = 1; i <= N; ++i){
		fscanf(fp, "%d", &list[i].currentValue);
		fscanf(fp,"%c", &buff);
		fscanf(fp, "%d", &list[i].minValue);
		fscanf(fp,"%c", &buff);
		
		list[i].worstcase=list[i].currentValue - list[i].minValue;

		fscanf(fp, "%d", &list[i].maxValue);
		fscanf(fp,"%c", &buff);
	}
	
    int **matrix = (int**)malloc(sizeof(int*)*(B+2));
    int **profit = (int**)malloc(sizeof(int*)*(B+2));
    int **spent = (int**)malloc(sizeof(int*)*(B+2));
    for (int i = 0; i <= B; ++i)
    {
    	matrix[i] = (int*)calloc((N+2),sizeof(int));
    	profit[i] = (int*)calloc((N+2),sizeof(int));
    	spent[i] = (int*)calloc((N+2),sizeof(int));
    }
	

	for (int i = 1; i <= B; i++)
	{
		for (int j = 1; j <= N+1; j++)
		{
			if((i-list[j].currentValue >=0 ) &&
				(matrix[i-list[j].currentValue][j-1] + list[j].worstcase <= L) &&
				(spent[i-list[j].currentValue][j-1] + list[j].currentValue <=B)){
	
				if(profit[i-1][j] < profit[i-list[j].currentValue][j-1]+list[j].maxValue-list[j].currentValue)
				{
					profit[i][j]=profit[i-list[j].currentValue][j-1]
					+list[j].maxValue-list[j].currentValue;
					matrix[i][j]=matrix[i-list[j].currentValue][j-1]
					+list[j].worstcase;
					spent[i][j]=spent[i-list[j].currentValue][j-1]
					+list[j].currentValue;
				}
				else
				{
					profit[i][j]=profit[i-1][j];
					matrix[i][j]=matrix[i-1][j];
					spent[i][j]=spent[i-1][j];
					
					if(profit[i][j] < profit[i][j-1]){
						profit[i][j]=profit[i][j-1];
						matrix[i][j]=matrix[i][j-1];
						spent[i][j]=spent[i][j-1];
					}

				}
				if(profit[i][j] < profit[i][j-1])
				{
					profit[i][j]=profit[i][j-1];
					matrix[i][j]=matrix[i][j-1];
					spent[i][j]=spent[i][j-1];
				}
			}
			else
			{
				if(profit[i-1][j] > profit[i][j-1]){
					profit[i][j]=profit[i-1][j];
					matrix[i][j]=matrix[i-1][j];
					spent[i][j]=spent[i-1][j];

				}
				else
				if(profit[i-1][j] < profit[i][j-1]){
					profit[i][j]=profit[i][j-1];
					matrix[i][j]=matrix[i][j-1];
					spent[i][j]=spent[i][j-1];
					
				}
				else
				if(profit[i-1][j] == profit[i][j-1]){
					profit[i][j]=profit[i][j-1];
					if(matrix[i-1][j] > matrix[i][j-1]){
						matrix[i][j]=matrix[i-1][j];	
						spent[i][j]=spent[i-1][j];	
					}
					else{
						matrix[i][j]=matrix[i][j-1];
						spent[i][j]=spent[i][j-1];	
					}
				}
			}
		}
	}
	
	/*
	for (int i = 1; i <= B; ++i)
	{
		for (int j = 1; j <= N+1; ++j)
		{
			fprintf(fp1,"%d ", profit[i][j]);
		}
		fprintf(fp1, "\n");
	}
	*/
	fprintf(fp1,"%d\n", profit[B][N+1]);



	fclose(fp);
	fclose(fp1);
	return 0;
}