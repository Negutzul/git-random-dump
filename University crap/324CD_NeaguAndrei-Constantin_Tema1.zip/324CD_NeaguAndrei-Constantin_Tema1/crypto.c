#include <stdlib.h>
#include <stdio.h>

typedef struct pcs
{
	int p;
	int u;
}pc;

void swap(pc* a, pc* b)
{
    pc t = *a;
    *a = *b;
    *b = t;
}


int partition (pc *arr, int low, int high)
{
	int pivot = arr[high].p;
	int i = (low - 1);

	for (int j = low; j <= high - 1; j++)
	{
    
		if (arr[j].p < pivot)
		{
			i++;
			swap(&arr[i], &arr[j]);
		}
	}
	swap(&arr[i + 1], &arr[high]);
	return (i + 1);
}

void quickSort(pc *arr, int low, int high)
{
    if (low < high)
    {
        int pi = partition(arr, low, high);

        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}


int main(){
	FILE *fp;
	fp = fopen("crypto.in", "r");
	FILE *fp1;
	fp1 = fopen("crypto.out", "w+");

	int N,B;
	char buff;
	fscanf(fp, "%d", &N);
	fscanf(fp,"%c", &buff);
	fscanf(fp, "%d", &B);
	fscanf(fp,"%c", &buff);	

   	pc *list = (pc*) malloc(sizeof(pc)*(2+N));
   	
	for (int i = 0; i < N; ++i){
		fscanf(fp, "%d", &list[i].p);
		fscanf(fp,"%c", &buff);
		fscanf(fp, "%d", &list[i].u);
		fscanf(fp,"%c", &buff);
	}

	fclose(fp);


	quickSort(list, 0, N-1);


	int counter=0;
	int sum=0;
	if(list[0].p==list[N-1].p){
		for (int i = 0; i < N; ++i)
		{
			sum+=list[i].u;
		}
		while((B-=sum)>0)
		{
			list[counter-1].p++;
		}
		fprintf(fp1,"%d", list[counter-1].p);
		fclose(fp1);
		return 0;
	}
	while(list[0].p==list[counter].p)
	{
		if(counter==N)
			break;
		sum+=list[counter].u;
		counter++;
	}

	while(B>0)
	{
		if((B-=sum)<0)
			break;
		else
		list[counter-1].p++;
		
		if(counter==N)
		{
			while((B-=sum)>0)
			{
				list[counter-1].p++;
			}
			break;
		}
		else
		if(list[counter-1].p==list[counter].p)
		{
			while(list[counter-1].p==list[counter].p)
			{
				if(counter==N)
					break;
				sum+=list[counter].u;
				counter++;
			}
		}

	}

	fprintf(fp1,"%d", list[counter-1].p);
	
	fclose(fp1);
	return 0;
}